Guess the number game written with `Angular2` and `TypeScript`.

Requires a static file server to execute

You can use [live-server][1], by installing

```bash
npm install -g live-server
```
Once installed just do

```bash
live-server
```
Start guessing!

[1]:https://www.npmjs.com/package/live-server
